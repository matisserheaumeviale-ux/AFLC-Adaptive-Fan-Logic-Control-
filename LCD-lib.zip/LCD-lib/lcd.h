#pragma once

#include "stm32f1xx_hal.h"

void LCD_Init(void);
void LCD_Clear(void);
void LCD_SendCommand(uint8_t cmd);
void LCD_SendChar(char data);
void LCD_SendString(char *str);
void LCD_SetCursor(uint8_t col, uint8_t row);

