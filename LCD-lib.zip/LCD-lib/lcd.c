#include "lcd.h"

#define RS_Pin GPIO_PIN_9
#define RS_Port GPIOB

#define RW_Pin GPIO_PIN_10
#define RW_Port GPIOB

#define EN_Pin GPIO_PIN_11
#define EN_Port GPIOB

#define D4_Pin GPIO_PIN_12
#define D4_Port GPIOB

#define D5_Pin GPIO_PIN_13
#define D5_Port GPIOB

#define D6_Pin GPIO_PIN_14
#define D6_Port GPIOB

#define D7_Pin GPIO_PIN_15
#define D7_Port GPIOB

static void LCD_EnablePulse(void){
  HAL_GPIO_WritePin(EN_Port, EN_Pin, GPIO_PIN_SET);
  HAL_Delay(1);
  HAL_GPIO_WritePin(EN_Port, EN_Pin, GPIO_PIN_RESET);
  HAL_Delay(1);
}

static void LCD_Send4Bits(uint8_t data){
  HAL_GPIO_WritePin(D4_Port, D4_Pin, ((data >> 0) & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(D5_Port, D5_Pin, ((data >> 1) & 0x01)  ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(D6_Port, D6_Pin, ((data >> 2) & 0x01)  ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(D7_Port, D7_Pin, ((data >> 3) & 0x01)  ? GPIO_PIN_SET : GPIO_PIN_RESET);
  
  LCD_EnablePulse();
}

void LCD_SendCommand(uint8_t data){
  HAL_GPIO_WritePin(RS_Port, RS_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(RW_Port, RW_Pin, GPIO_PIN_RESET);
  
  LCD_Send4Bits(data >> 4);
  LCD_Send4Bits(data & 0x0F);
}

void LCD_SendChar(char data){
  HAL_GPIO_WritePin(RS_Port, RS_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(RW_Port, RW_Pin, GPIO_PIN_RESET);
  
  LCD_Send4Bits(data >> 4);
  LCD_Send4Bits(data & 0x0F);
}

void LCD_SendString(char *str){
  while (*str) LCD_SendChar(*str++);
}

void LCD_SetCursor(uint8_t col, uint8_t row){
  uint8_t RowAddress[4] = {0x80, 0xC0, 0x94, 0xD4};
  LCD_SendCommand( 0x80| (RowAddress[row] + col));
}

void LCD_Init(void){
  HAL_Delay(50);
  
  LCD_SendCommand(0x33);
  LCD_SendCommand(0x32);
  
  LCD_SendCommand(0x28);
  LCD_SendCommand(0x0C);
  LCD_SendCommand(0x06);
  LCD_SendCommand(0x01);
  HAL_Delay(2);
 
}

void LCD_Clear(void){
  LCD_SendCommand(0x01);
  HAL_Delay(2);
}


